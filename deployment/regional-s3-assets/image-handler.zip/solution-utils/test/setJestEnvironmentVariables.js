// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
process.env.SOLUTION_ID = "solution-id";
process.env.SOLUTION_VERSION = "solution-version";
process.env.LOGGING_LEVEL = "VERBOSE";
//# sourceMappingURL=setJestEnvironmentVariables.js.map