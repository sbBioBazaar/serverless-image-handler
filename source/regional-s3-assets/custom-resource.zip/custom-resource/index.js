"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const ec2_1 = __importDefault(require("aws-sdk/clients/ec2"));
const s3_1 = __importDefault(require("aws-sdk/clients/s3"));
const secretsmanager_1 = __importDefault(require("aws-sdk/clients/secretsmanager"));
const axios_1 = __importDefault(require("axios"));
const crypto_1 = require("crypto");
const moment_1 = __importDefault(require("moment"));
const uuid_1 = require("uuid");
const get_options_1 = require("../solution-utils/get-options");
const helpers_1 = require("../solution-utils/helpers");
const lib_1 = require("./lib");
const awsSdkOptions = (0, get_options_1.getOptions)();
const s3Client = new s3_1.default(awsSdkOptions);
const ec2Client = new ec2_1.default(awsSdkOptions);
const secretsManager = new secretsmanager_1.default(awsSdkOptions);
const { SOLUTION_ID, SOLUTION_VERSION, AWS_REGION, RETRY_SECONDS } = process.env;
const METRICS_ENDPOINT = "https://metrics.awssolutionsbuilder.com/generic";
const RETRY_COUNT = 3;
/**
 * Custom resource Lambda handler.
 * @param event The custom resource request.
 * @param context The custom resource context.
 * @returns Processed request response.
 */
function handler(event, context) {
    var _a, _b;
    return __awaiter(this, void 0, void 0, function* () {
        console.info("Received event:", JSON.stringify(event, null, 2));
        const { RequestType, ResourceProperties } = event;
        const response = {
            Status: lib_1.StatusTypes.SUCCESS,
            Data: {},
        };
        try {
            switch (ResourceProperties.CustomAction) {
                case lib_1.CustomResourceActions.SEND_ANONYMOUS_METRIC: {
                    const requestProperties = ResourceProperties;
                    if (requestProperties.AnonymousData === "Yes") {
                        response.Data = yield sendAnonymousMetric(requestProperties, RequestType);
                    }
                    break;
                }
                case lib_1.CustomResourceActions.PUT_CONFIG_FILE: {
                    const allowedRequestTypes = [lib_1.CustomResourceRequestTypes.CREATE, lib_1.CustomResourceRequestTypes.UPDATE];
                    yield performRequest(putConfigFile, RequestType, allowedRequestTypes, response, ResourceProperties);
                    break;
                }
                case lib_1.CustomResourceActions.COPY_S3_ASSETS: {
                    const allowedRequestTypes = [lib_1.CustomResourceRequestTypes.CREATE, lib_1.CustomResourceRequestTypes.UPDATE];
                    yield performRequest(copyS3Assets, RequestType, allowedRequestTypes, response, ResourceProperties);
                    break;
                }
                case lib_1.CustomResourceActions.CREATE_UUID: {
                    const allowedRequestTypes = [lib_1.CustomResourceRequestTypes.CREATE];
                    yield performRequest(generateUUID, RequestType, allowedRequestTypes, response);
                    break;
                }
                case lib_1.CustomResourceActions.CHECK_SOURCE_BUCKETS: {
                    const allowedRequestTypes = [lib_1.CustomResourceRequestTypes.CREATE, lib_1.CustomResourceRequestTypes.UPDATE];
                    yield performRequest(validateBuckets, RequestType, allowedRequestTypes, response, ResourceProperties);
                    break;
                }
                case lib_1.CustomResourceActions.CHECK_SECRETS_MANAGER: {
                    const allowedRequestTypes = [lib_1.CustomResourceRequestTypes.CREATE, lib_1.CustomResourceRequestTypes.UPDATE];
                    yield performRequest(checkSecretsManager, RequestType, allowedRequestTypes, response, ResourceProperties);
                    break;
                }
                case lib_1.CustomResourceActions.CHECK_FALLBACK_IMAGE: {
                    const allowedRequestTypes = [lib_1.CustomResourceRequestTypes.CREATE, lib_1.CustomResourceRequestTypes.UPDATE];
                    yield performRequest(checkFallbackImage, RequestType, allowedRequestTypes, response, ResourceProperties);
                    break;
                }
                case lib_1.CustomResourceActions.CREATE_LOGGING_BUCKET: {
                    const allowedRequestTypes = [lib_1.CustomResourceRequestTypes.CREATE];
                    yield performRequest(createCloudFrontLoggingBucket, RequestType, allowedRequestTypes, response, ResourceProperties);
                    break;
                }
                default:
                    break;
            }
        }
        catch (error) {
            console.error(`Error occurred at ${event.RequestType}::${ResourceProperties.CustomAction}`, error);
            response.Status = lib_1.StatusTypes.FAILED;
            response.Data.Error = {
                Code: (_a = error.code) !== null && _a !== void 0 ? _a : "CustomResourceError",
                Message: (_b = error.message) !== null && _b !== void 0 ? _b : "Custom resource error occurred.",
            };
        }
        finally {
            yield sendCloudFormationResponse(event, context.logStreamName, response);
        }
        return response;
    });
}
exports.handler = handler;
/**
 *
 * @param functionToPerform a function to perform
 * @param requestType the type of request
 * @param allowedRequestTypes the type or requests to allow
 * @param response the response object
 * @param resourceProperties the parameters to include in the function to be performed
 */
function performRequest(functionToPerform, requestType, allowedRequestTypes, response, resourceProperties) {
    return __awaiter(this, void 0, void 0, function* () {
        if (allowedRequestTypes.includes(requestType)) {
            response.Data = yield functionToPerform(resourceProperties);
        }
    });
}
/**
 * Suspends for the specified amount of seconds.
 * @param timeOut The number of seconds for which the call is suspended.
 * @returns Sleep promise.
 */
function sleep(timeOut) {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve) => setTimeout(resolve, timeOut));
    });
}
/**
 * Gets retry timeout based on the current retry attempt in seconds.
 * @param attempt Retry attempt.
 * @returns Timeout in seconds.
 */
function getRetryTimeout(attempt) {
    const retrySeconds = Number(RETRY_SECONDS);
    return retrySeconds * 1000 * attempt;
}
/**
 * Get content type by file name.
 * @param filename File name.
 * @returns Content type.
 */
function getContentType(filename) {
    let contentType = "";
    if (filename.endsWith(".html")) {
        contentType = "text/html";
    }
    else if (filename.endsWith(".css")) {
        contentType = "text/css";
    }
    else if (filename.endsWith(".png")) {
        contentType = "image/png";
    }
    else if (filename.endsWith(".svg")) {
        contentType = "image/svg+xml";
    }
    else if (filename.endsWith(".jpg")) {
        contentType = "image/jpeg";
    }
    else if (filename.endsWith(".js")) {
        contentType = "application/javascript";
    }
    else {
        contentType = "binary/octet-stream";
    }
    return contentType;
}
/**
 * Send custom resource response.
 * @param event Custom resource event.
 * @param logStreamName Custom resource log stream name.
 * @param response Response completion status.
 * @returns The promise of the sent request.
 */
function sendCloudFormationResponse(event, logStreamName, response) {
    return __awaiter(this, void 0, void 0, function* () {
        const responseBody = JSON.stringify({
            Status: response.Status,
            Reason: `See the details in CloudWatch Log Stream: ${logStreamName}`,
            PhysicalResourceId: event.LogicalResourceId,
            StackId: event.StackId,
            RequestId: event.RequestId,
            LogicalResourceId: event.LogicalResourceId,
            Data: response.Data,
        });
        const config = {
            headers: {
                "Content-Type": "",
                "Content-Length": responseBody.length,
            },
        };
        return axios_1.default.put(event.ResponseURL, responseBody, config);
    });
}
/**
 * Sends anonymous metrics.
 * @param requestProperties The send metrics request properties.
 * @param requestType The request type.
 * @returns Promise message object.
 */
function sendAnonymousMetric(requestProperties, requestType) {
    var _a;
    return __awaiter(this, void 0, void 0, function* () {
        const result = {
            Message: "",
            Data: undefined,
        };
        try {
            const numberOfSourceBuckets = ((_a = requestProperties.SourceBuckets) === null || _a === void 0 ? void 0 : _a.split(",").map((x) => x.trim()).filter((x) => !(0, helpers_1.isNullOrWhiteSpace)(x)).length) || 0;
            const payload = {
                Solution: SOLUTION_ID,
                Version: SOLUTION_VERSION,
                UUID: requestProperties.UUID,
                TimeStamp: moment_1.default.utc().format("YYYY-MM-DD HH:mm:ss.S"),
                Data: {
                    Region: AWS_REGION,
                    Type: requestType,
                    CorsEnabled: requestProperties.CorsEnabled,
                    NumberOfSourceBuckets: numberOfSourceBuckets,
                    DeployDemoUi: requestProperties.DeployDemoUi,
                    LogRetentionPeriod: requestProperties.LogRetentionPeriod,
                    AutoWebP: requestProperties.AutoWebP,
                    EnableSignature: requestProperties.EnableSignature,
                    EnableDefaultFallbackImage: requestProperties.EnableDefaultFallbackImage,
                },
            };
            result.Data = payload;
            const payloadStr = JSON.stringify(payload);
            const config = {
                headers: {
                    "content-type": "application/json",
                    "content-length": payloadStr.length,
                },
            };
            console.info("Sending anonymous metric", payloadStr);
            const response = yield axios_1.default.post(METRICS_ENDPOINT, payloadStr, config);
            console.info(`Anonymous metric response: ${response.statusText} (${response.status})`);
            result.Message = "Anonymous data was sent successfully.";
        }
        catch (err) {
            console.error("Error sending anonymous metric");
            console.error(err);
            result.Message = "Anonymous data was sent failed.";
        }
        return result;
    });
}
/**
 * Puts the config file into S3 bucket.
 * @param requestProperties The request properties.
 * @returns Result of the putting config file.
 */
function putConfigFile(requestProperties) {
    return __awaiter(this, void 0, void 0, function* () {
        const { ConfigItem, DestS3Bucket, DestS3key } = requestProperties;
        console.info(`Attempting to save content blob destination location: ${DestS3Bucket}/${DestS3key}`);
        console.info(JSON.stringify(ConfigItem, null, 2));
        const configFieldValues = Object.entries(ConfigItem)
            .map(([key, value]) => `${key}: '${value}'`)
            .join(",\n");
        const content = `'use strict';\n\nconst appVariables = {\n${configFieldValues}\n};`;
        // In case getting object fails due to asynchronous IAM permission creation, it retries.
        const params = {
            Bucket: DestS3Bucket,
            Body: content,
            Key: DestS3key,
            ContentType: getContentType(DestS3key),
        };
        for (let retry = 1; retry <= RETRY_COUNT; retry++) {
            try {
                console.info(`Putting ${DestS3key}... Try count: ${retry}`);
                yield s3Client.putObject(params).promise();
                console.info(`Putting ${DestS3key} completed.`);
                break;
            }
            catch (error) {
                if (retry === RETRY_COUNT || error.code !== lib_1.ErrorCodes.ACCESS_DENIED) {
                    console.info(`Error occurred while putting ${DestS3key} into ${DestS3Bucket} bucket.`, error);
                    throw new lib_1.CustomResourceError("ConfigFileCreationFailure", `Saving config file to ${DestS3Bucket}/${DestS3key} failed.`);
                }
                else {
                    console.info("Waiting for retry...");
                    yield sleep(getRetryTimeout(retry));
                }
            }
        }
        return {
            Message: "Config file uploaded.",
            Content: content,
        };
    });
}
/**
 * Copies assets from the source S3 bucket to the destination S3 bucket.
 * @param requestProperties The request properties.
 * @returns The result of copying assets.
 */
function copyS3Assets(requestProperties) {
    return __awaiter(this, void 0, void 0, function* () {
        const { ManifestKey, SourceS3Bucket, SourceS3key, DestS3Bucket } = requestProperties;
        console.info(`Source bucket: ${SourceS3Bucket}`);
        console.info(`Source prefix: ${SourceS3key}`);
        console.info(`Destination bucket: ${DestS3Bucket}`);
        let manifest;
        // Download manifest
        for (let retry = 1; retry <= RETRY_COUNT; retry++) {
            try {
                const getParams = {
                    Bucket: SourceS3Bucket,
                    Key: ManifestKey,
                };
                const response = yield s3Client.getObject(getParams).promise();
                manifest = JSON.parse(response.Body.toString());
                break;
            }
            catch (error) {
                if (retry === RETRY_COUNT || error.code !== lib_1.ErrorCodes.ACCESS_DENIED) {
                    console.error("Error occurred while getting manifest file.");
                    console.error(error);
                    throw new lib_1.CustomResourceError("GetManifestFailure", "Copy of website assets failed.");
                }
                else {
                    console.info("Waiting for retry...");
                    yield sleep(getRetryTimeout(retry));
                }
            }
        }
        // Copy asset files
        try {
            yield Promise.all(manifest.files.map((fileName) => __awaiter(this, void 0, void 0, function* () {
                const copyObjectParams = {
                    Bucket: DestS3Bucket,
                    CopySource: `${SourceS3Bucket}/${SourceS3key}/${fileName}`,
                    Key: fileName,
                    ContentType: getContentType(fileName),
                };
                console.debug(`Copying ${fileName} to ${DestS3Bucket}`);
                return s3Client.copyObject(copyObjectParams).promise();
            })));
            return {
                Message: "Copy assets completed.",
                Manifest: { Files: manifest.files },
            };
        }
        catch (error) {
            console.error("Error occurred while copying assets.");
            console.error(error);
            throw new lib_1.CustomResourceError("CopyAssetsFailure", "Copy of website assets failed.");
        }
    });
}
/**
 * Generates UUID.
 * @returns Generated UUID.
 */
function generateUUID() {
    return __awaiter(this, void 0, void 0, function* () {
        return Promise.resolve({ UUID: (0, uuid_1.v4)() });
    });
}
/**
 * Validates if buckets exist in the account.
 * @param requestProperties The request properties.
 * @returns The result of validation.
 */
function validateBuckets(requestProperties) {
    return __awaiter(this, void 0, void 0, function* () {
        const { SourceBuckets } = requestProperties;
        const buckets = SourceBuckets.replace(/\s/g, "");
        console.info(`Attempting to check if the following buckets exist: ${buckets}`);
        const checkBuckets = buckets.split(",");
        const errorBuckets = [];
        for (const bucket of checkBuckets) {
            const params = { Bucket: bucket };
            try {
                yield s3Client.headBucket(params).promise();
                console.info(`Found bucket: ${bucket}`);
            }
            catch (error) {
                console.error(`Could not find bucket: ${bucket}`);
                console.error(error);
                errorBuckets.push(bucket);
            }
        }
        if (errorBuckets.length === 0) {
            return { Message: "Buckets validated." };
        }
        else {
            const commaSeparatedErrors = errorBuckets.join(",");
            throw new lib_1.CustomResourceError("BucketNotFound", `Could not find the following source bucket(s) in your account: ${commaSeparatedErrors}. Please specify at least one source bucket that exists within your account and try again. If specifying multiple source buckets, please ensure that they are comma-separated.`);
        }
    });
}
/**
 * Checks if AWS Secrets Manager secret is valid.
 * @param requestProperties The request properties.
 * @returns ARN of the AWS Secrets Manager secret.
 */
function checkSecretsManager(requestProperties) {
    return __awaiter(this, void 0, void 0, function* () {
        const { SecretsManagerName, SecretsManagerKey } = requestProperties;
        if ((0, helpers_1.isNullOrWhiteSpace)(SecretsManagerName)) {
            throw new lib_1.CustomResourceError("SecretNotProvided", "You need to provide AWS Secrets Manager secret.");
        }
        if ((0, helpers_1.isNullOrWhiteSpace)(SecretsManagerKey)) {
            throw new lib_1.CustomResourceError("SecretKeyNotProvided", "You need to provide AWS Secrets Manager secret key.");
        }
        let arn = "";
        for (let retry = 1; retry <= RETRY_COUNT; retry++) {
            try {
                const response = yield secretsManager.getSecretValue({ SecretId: SecretsManagerName }).promise();
                const secretString = JSON.parse(response.SecretString);
                if (!Object.prototype.hasOwnProperty.call(secretString, SecretsManagerKey)) {
                    throw new lib_1.CustomResourceError("SecretKeyNotFound", `AWS Secrets Manager secret requires ${SecretsManagerKey} key.`);
                }
                arn = response.ARN;
                break;
            }
            catch (error) {
                if (retry === RETRY_COUNT) {
                    console.error(`AWS Secrets Manager secret or signature might not exist: ${SecretsManagerName}/${SecretsManagerKey}`);
                    throw error;
                }
                else {
                    console.info("Waiting for retry...");
                    yield sleep(getRetryTimeout(retry));
                }
            }
        }
        return {
            Message: "Secrets Manager validated.",
            ARN: arn,
        };
    });
}
/**
 * Checks fallback image.
 * @param requestProperties The request properties.
 * @returns The result of validation.
 */
function checkFallbackImage(requestProperties) {
    return __awaiter(this, void 0, void 0, function* () {
        const { FallbackImageS3Bucket, FallbackImageS3Key } = requestProperties;
        if ((0, helpers_1.isNullOrWhiteSpace)(FallbackImageS3Bucket)) {
            throw new lib_1.CustomResourceError("S3BucketNotProvided", "You need to provide the default fallback image bucket.");
        }
        if ((0, helpers_1.isNullOrWhiteSpace)(FallbackImageS3Key)) {
            throw new lib_1.CustomResourceError("S3KeyNotProvided", "You need to provide the default fallback image object key.");
        }
        let data = {};
        for (let retry = 1; retry <= RETRY_COUNT; retry++) {
            try {
                data = yield s3Client.headObject({ Bucket: FallbackImageS3Bucket, Key: FallbackImageS3Key }).promise();
                break;
            }
            catch (error) {
                if (retry === RETRY_COUNT || ![lib_1.ErrorCodes.ACCESS_DENIED, lib_1.ErrorCodes.FORBIDDEN].includes(error.code)) {
                    console.error(`Either the object does not exist or you don't have permission to access the object: ${FallbackImageS3Bucket}/${FallbackImageS3Key}`);
                    throw new lib_1.CustomResourceError("FallbackImageError", `Either the object does not exist or you don't have permission to access the object: ${FallbackImageS3Bucket}/${FallbackImageS3Key}`);
                }
                else {
                    console.info("Waiting for retry...");
                    yield sleep(getRetryTimeout(retry));
                }
            }
        }
        return {
            Message: "The default fallback image validated.",
            Data: data,
        };
    });
}
/**
 * Creates a bucket with settings for cloudfront logging.
 * @param requestProperties The request properties.
 * @returns Bucket name of the created bucket.
 */
function createCloudFrontLoggingBucket(requestProperties) {
    return __awaiter(this, void 0, void 0, function* () {
        const logBucketSuffix = (0, crypto_1.createHash)("md5")
            .update(`${requestProperties.BucketSuffix}${moment_1.default.utc().valueOf()}`)
            .digest("hex");
        const bucketName = `serverless-image-handler-logs-${logBucketSuffix.substring(0, 8)}`.toLowerCase();
        // the S3 bucket will be created in 'us-east-1' if the current region is in opt-in regions,
        // because CloudFront does not currently deliver access logs to opt-in region buckets
        const isOptInRegion = yield checkRegionOptInStatus(AWS_REGION);
        const targetRegion = isOptInRegion ? "us-east-1" : AWS_REGION;
        console.info(`The opt-in status of the '${AWS_REGION}' region is '${isOptInRegion ? "opted-in" : "opt-in-not-required"}'`);
        // create bucket
        try {
            const s3Client = new s3_1.default(Object.assign(Object.assign({}, awsSdkOptions), { apiVersion: "2006-03-01", region: targetRegion }));
            const createBucketRequestParams = {
                Bucket: bucketName,
                ACL: "log-delivery-write",
            };
            yield s3Client.createBucket(createBucketRequestParams).promise();
            console.info(`Successfully created bucket '${bucketName}' in '${targetRegion}' region`);
        }
        catch (error) {
            console.error(`Could not create bucket '${bucketName}'`);
            console.error(error);
            throw error;
        }
        // add encryption to bucket
        console.info("Adding Encryption...");
        try {
            const putBucketEncryptionRequestParams = {
                Bucket: bucketName,
                ServerSideEncryptionConfiguration: {
                    Rules: [{ ApplyServerSideEncryptionByDefault: { SSEAlgorithm: "AES256" } }],
                },
            };
            yield s3Client.putBucketEncryption(putBucketEncryptionRequestParams).promise();
            console.info(`Successfully enabled encryption on bucket '${bucketName}'`);
        }
        catch (error) {
            console.error(`Failed to add encryption to bucket '${bucketName}'`);
            console.error(error);
            throw error;
        }
        // add policy to bucket
        try {
            console.info("Adding policy...");
            const bucketPolicyStatement = {
                Resource: `arn:aws:s3:::${bucketName}/*`,
                Action: "*",
                Effect: "Deny",
                Principal: "*",
                Sid: "HttpsOnly",
                Condition: { Bool: { "aws:SecureTransport": "false" } },
            };
            const bucketPolicy = {
                Version: "2012-10-17",
                Statement: [bucketPolicyStatement],
            };
            const putBucketPolicyRequestParams = {
                Bucket: bucketName,
                Policy: JSON.stringify(bucketPolicy),
            };
            yield s3Client.putBucketPolicy(putBucketPolicyRequestParams).promise();
            console.info(`Successfully added policy added to bucket '${bucketName}'`);
        }
        catch (error) {
            console.error(`Failed to add policy to bucket '${bucketName}'`);
            console.error(error);
            throw error;
        }
        return { BucketName: bucketName, Region: targetRegion };
    });
}
/**
 * Checks if the region is opted-in or not.
 * @param region The region to check.
 * @returns The result of check.
 */
function checkRegionOptInStatus(region) {
    return __awaiter(this, void 0, void 0, function* () {
        const describeRegionsRequestParams = {
            RegionNames: [region],
            Filters: [{ Name: "opt-in-status", Values: ["opted-in"] }],
        };
        const describeRegionsResponse = yield ec2Client.describeRegions(describeRegionsRequestParams).promise();
        return describeRegionsResponse.Regions.length > 0;
    });
}
//# sourceMappingURL=index.js.map