"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mock_1 = require("../mock");
const rekognition_1 = __importDefault(require("aws-sdk/clients/rekognition"));
const s3_1 = __importDefault(require("aws-sdk/clients/s3"));
const sharp_1 = __importDefault(require("sharp"));
const image_handler_1 = require("../../image-handler");
const lib_1 = require("../../lib");
const s3Client = new s3_1.default();
const rekognitionClient = new rekognition_1.default();
describe("smartCrop", () => {
    it("Should pass if an edit with the smartCrop keyname is passed to the function", () => __awaiter(void 0, void 0, void 0, function* () {
        // Arrange
        const originalImage = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==", "base64");
        const image = (0, sharp_1.default)(originalImage, { failOnError: false }).withMetadata();
        const buffer = yield image.toBuffer();
        const edits = { smartCrop: { faceIndex: 0, padding: 0 } };
        // Mock
        mock_1.mockAwsRekognition.detectFaces.mockImplementationOnce(() => ({
            promise() {
                return Promise.resolve({
                    FaceDetails: [
                        {
                            BoundingBox: { Height: 0.18, Left: 0.55, Top: 0.33, Width: 0.23 },
                        },
                    ],
                });
            },
        }));
        // Act
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        const result = yield imageHandler.applyEdits(image, edits, false);
        // Assert
        expect(mock_1.mockAwsRekognition.detectFaces).toHaveBeenCalledWith({
            Image: { Bytes: buffer },
        });
        expect(result["options"].input).not.toEqual(originalImage);
    }));
    it("Should pass if an excessive padding value is passed to the smartCrop filter", () => __awaiter(void 0, void 0, void 0, function* () {
        // Arrange
        const originalImage = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==", "base64");
        const image = (0, sharp_1.default)(originalImage, { failOnError: false }).withMetadata();
        const buffer = yield image.toBuffer();
        const edits = { smartCrop: { faceIndex: 0, padding: 80 } };
        // Mock
        mock_1.mockAwsRekognition.detectFaces.mockImplementationOnce(() => ({
            promise() {
                return Promise.resolve({
                    FaceDetails: [
                        {
                            BoundingBox: { Height: 0.18, Left: 0.55, Top: 0.33, Width: 0.23 },
                        },
                    ],
                });
            },
        }));
        // Act
        try {
            const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
            yield imageHandler.applyEdits(image, edits, false);
        }
        catch (error) {
            // Assert
            expect(mock_1.mockAwsRekognition.detectFaces).toHaveBeenCalledWith({
                Image: { Bytes: buffer },
            });
            expect(error).toMatchObject({
                status: lib_1.StatusCodes.BAD_REQUEST,
                code: "SmartCrop::PaddingOutOfBounds",
                message: "The padding value you provided exceeds the boundaries of the original image. Please try choosing a smaller value or applying padding via Sharp for greater specificity.",
            });
        }
    }));
    it("Should pass if an excessive faceIndex value is passed to the smartCrop filter", () => __awaiter(void 0, void 0, void 0, function* () {
        // Arrange
        const originalImage = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==", "base64");
        const image = (0, sharp_1.default)(originalImage, { failOnError: false }).withMetadata();
        const buffer = yield image.toBuffer();
        const edits = { smartCrop: { faceIndex: 10, padding: 0 } };
        // Mock
        mock_1.mockAwsRekognition.detectFaces.mockImplementationOnce(() => ({
            promise() {
                return Promise.resolve({
                    FaceDetails: [
                        {
                            BoundingBox: { Height: 0.18, Left: 0.55, Top: 0.33, Width: 0.23 },
                        },
                    ],
                });
            },
        }));
        // Act
        try {
            const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
            yield imageHandler.applyEdits(image, edits, false);
        }
        catch (error) {
            // Assert
            expect(mock_1.mockAwsRekognition.detectFaces).toHaveBeenCalledWith({
                Image: { Bytes: buffer },
            });
            expect(error).toMatchObject({
                status: lib_1.StatusCodes.BAD_REQUEST,
                code: "SmartCrop::FaceIndexOutOfRange",
                message: "You have provided a FaceIndex value that exceeds the length of the zero-based detectedFaces array. Please specify a value that is in-range.",
            });
        }
    }));
    it("Should pass if a faceIndex value of undefined is passed to the smartCrop filter", () => __awaiter(void 0, void 0, void 0, function* () {
        // Arrange
        const originalImage = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==", "base64");
        const image = (0, sharp_1.default)(originalImage, { failOnError: false }).withMetadata();
        const buffer = yield image.toBuffer();
        const edits = { smartCrop: true };
        // Mock
        mock_1.mockAwsRekognition.detectFaces.mockImplementationOnce(() => ({
            promise() {
                return Promise.resolve({
                    FaceDetails: [
                        {
                            BoundingBox: { Height: 0.18, Left: 0.55, Top: 0.33, Width: 0.23 },
                        },
                    ],
                });
            },
        }));
        // Act
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        const result = yield imageHandler.applyEdits(image, edits, false);
        // Assert
        expect(mock_1.mockAwsRekognition.detectFaces).toHaveBeenCalledWith({
            Image: { Bytes: buffer },
        });
        expect(result["options"].input).not.toEqual(originalImage); // eslint-disable-line dot-notation
    }));
    it("Should pass if the crop area can be calculated using a series of valid inputs/parameters", () => {
        // Arrange
        const boundingBox = {
            height: 0.18,
            left: 0.55,
            top: 0.33,
            width: 0.23,
        };
        const metadata = { width: 200, height: 400 };
        // Act
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        const result = imageHandler.getCropArea(boundingBox, 20, metadata);
        // Assert
        const expectedResult = {
            left: 90,
            top: 112,
            width: 86,
            height: 112,
        };
        expect(result).toEqual(expectedResult);
    });
    it("Should pass if the crop area is beyond the range of the image after padding is applied", () => {
        // Arrange
        const boundingBox = {
            height: 0.18,
            left: 0.55,
            top: 0.33,
            width: 0.23,
        };
        const metadata = { width: 200, height: 400 };
        // Act
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        const result = imageHandler.getCropArea(boundingBox, 500, metadata);
        // Assert
        const expectedResult = {
            left: 0,
            top: 0,
            width: 200,
            height: 400,
        };
        expect(result).toEqual(expectedResult);
    });
    it("Should pass if the proper parameters are passed to the function", () => __awaiter(void 0, void 0, void 0, function* () {
        // Arrange
        const currentImage = Buffer.from("TestImageData");
        const faceIndex = 0;
        // Mock
        mock_1.mockAwsRekognition.detectFaces.mockImplementationOnce(() => ({
            promise() {
                return Promise.resolve({
                    FaceDetails: [
                        {
                            BoundingBox: { Height: 0.18, Left: 0.55, Top: 0.33, Width: 0.23 },
                        },
                    ],
                });
            },
        }));
        // Act
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        const result = yield imageHandler.getBoundingBox(currentImage, faceIndex);
        // Assert
        const expectedResult = {
            height: 0.18,
            left: 0.55,
            top: 0.33,
            width: 0.23,
        };
        expect(mock_1.mockAwsRekognition.detectFaces).toHaveBeenCalledWith({
            Image: { Bytes: currentImage },
        });
        expect(result).toEqual(expectedResult);
    }));
    it("Should simulate an error condition returned by Rekognition", () => __awaiter(void 0, void 0, void 0, function* () {
        // Arrange
        const currentImage = Buffer.from("NotTestImageData");
        const faceIndex = 0;
        // Mock
        mock_1.mockAwsRekognition.detectFaces.mockImplementationOnce(() => ({
            promise() {
                return Promise.reject(new lib_1.ImageHandlerError(lib_1.StatusCodes.INTERNAL_SERVER_ERROR, "InternalServerError", "SimulatedError"));
            },
        }));
        // Act
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        try {
            yield imageHandler.getBoundingBox(currentImage, faceIndex);
        }
        catch (error) {
            // Assert
            expect(mock_1.mockAwsRekognition.detectFaces).toHaveBeenCalledWith({
                Image: { Bytes: currentImage },
            });
            expect(error).toMatchObject({
                status: lib_1.StatusCodes.INTERNAL_SERVER_ERROR,
                code: "InternalServerError",
                message: "SimulatedError",
            });
        }
    }));
    it("Should pass if no faces are detected", () => __awaiter(void 0, void 0, void 0, function* () {
        // Arrange
        const currentImage = Buffer.from("TestImageData");
        const faceIndex = 0;
        // Mock
        mock_1.mockAwsRekognition.detectFaces.mockImplementationOnce(() => ({
            promise() {
                return Promise.resolve({ FaceDetails: [] });
            },
        }));
        // Act
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        const result = yield imageHandler.getBoundingBox(currentImage, faceIndex);
        // Assert
        const expectedResult = {
            height: 1,
            left: 0,
            top: 0,
            width: 1,
        };
        expect(mock_1.mockAwsRekognition.detectFaces).toHaveBeenCalledWith({
            Image: { Bytes: currentImage },
        });
        expect(result).toEqual(expectedResult);
    }));
    it("Should pass if bounds detected go beyond the image dimensions", () => __awaiter(void 0, void 0, void 0, function* () {
        // Arrange
        const currentImage = Buffer.from("TestImageData");
        const faceIndex = 0;
        // Mock
        mock_1.mockAwsRekognition.detectFaces.mockImplementationOnce(() => ({
            promise() {
                return Promise.resolve({
                    FaceDetails: [
                        {
                            BoundingBox: { Height: 1, Left: 0.5, Top: 0.3, Width: 0.65 },
                        },
                    ],
                });
            },
        }));
        // Act
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        const result = yield imageHandler.getBoundingBox(currentImage, faceIndex);
        // Assert
        const expectedResult = {
            height: 0.7,
            left: 0.5,
            top: 0.3,
            width: 0.5,
        };
        expect(mock_1.mockAwsRekognition.detectFaces).toHaveBeenCalledWith({
            Image: { Bytes: currentImage },
        });
        expect(result).toEqual(expectedResult);
    }));
});
describe("handleBounds", () => {
    it("Should set bounding box with a bounding box that matches rekognition when the bounds are within the image size", () => {
        // Arrange
        const boundingBox = {};
        const rekognitionResponse = {
            FaceDetails: [
                {
                    AgeRange: {
                        High: 43,
                        Low: 26,
                    },
                    BoundingBox: {
                        Height: 0.6968063116073608,
                        Left: 0.26937249302864075,
                        Top: 0.11424895375967026,
                        Width: 0.42325547337532043,
                    },
                },
            ],
        };
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        // Act
        imageHandler["handleBounds"](rekognitionResponse, 0, boundingBox);
        // Assert
        expect(boundingBox).toEqual({
            Height: 0.6968063116073608,
            Left: 0.26937249302864075,
            Top: 0.11424895375967026,
            Width: 0.42325547337532043,
        });
    });
    it("Should set bounding box with a bounding box with width set to (1 - left) when the bounds are wider than the image", () => {
        // Arrange
        const boundingBox = {};
        const rekognitionResponse = {
            FaceDetails: [
                {
                    AgeRange: {
                        High: 43,
                        Low: 26,
                    },
                    BoundingBox: {
                        Height: 0.6968063116073608,
                        Left: 0.76937249302864075,
                        Top: 0.11424895375967026,
                        Width: 0.42325547337532043,
                    },
                },
            ],
        };
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        // Act
        imageHandler["handleBounds"](rekognitionResponse, 0, boundingBox);
        // Assert
        expect(boundingBox).toEqual({
            Height: 0.6968063116073608,
            Left: 0.76937249302864075,
            Top: 0.11424895375967026,
            Width: 1 - 0.76937249302864075,
        });
    });
    it("Should set bounding box with a bounding box with height set to (1 - top) when the bounds are wider than the image", () => {
        // Arrange
        const boundingBox = {};
        const rekognitionResponse = {
            FaceDetails: [
                {
                    AgeRange: {
                        High: 43,
                        Low: 26,
                    },
                    BoundingBox: {
                        Height: 0.6968063116073608,
                        Left: 0.26937249302864075,
                        Top: 0.51424895375967026,
                        Width: 0.42325547337532043,
                    },
                },
            ],
        };
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        // Act
        imageHandler["handleBounds"](rekognitionResponse, 0, boundingBox);
        // Assert
        expect(boundingBox).toEqual({
            Height: 1 - 0.51424895375967026,
            Left: 0.26937249302864075,
            Top: 0.51424895375967026,
            Width: 0.42325547337532043,
        });
    });
    it("Should set bounding box with a height set to (1 - top) when height is greater than the 1", () => {
        // Arrange
        const boundingBox = {};
        const rekognitionResponse = {
            FaceDetails: [
                {
                    AgeRange: {
                        High: 43,
                        Low: 26,
                    },
                    BoundingBox: {
                        Height: 1.6968063116073608,
                        Left: 0.26937249302864075,
                        Top: 0.11424895375967026,
                        Width: 0.42325547337532043,
                    },
                },
            ],
        };
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        // Act
        imageHandler["handleBounds"](rekognitionResponse, 0, boundingBox);
        // Assert
        expect(boundingBox).toEqual({
            Height: 1 - 0.11424895375967026,
            Left: 0.26937249302864075,
            Top: 0.11424895375967026,
            Width: 0.42325547337532043,
        });
    });
    it("Should set bounding box with a height set to (1 - left) when width is greater than the 1", () => {
        // Arrange
        const boundingBox = {};
        const rekognitionResponse = {
            FaceDetails: [
                {
                    AgeRange: {
                        High: 43,
                        Low: 26,
                    },
                    BoundingBox: {
                        Height: 0.6968063116073608,
                        Left: 0.26937249302864075,
                        Top: 0.11424895375967026,
                        Width: 5.42325547337532043,
                    },
                },
            ],
        };
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        // Act
        imageHandler["handleBounds"](rekognitionResponse, 0, boundingBox);
        // Assert
        expect(boundingBox).toEqual({
            Height: 0.6968063116073608,
            Left: 0.26937249302864075,
            Top: 0.11424895375967026,
            Width: 1 - 0.26937249302864075,
        });
    });
    it("Should set bounding box with a top set to 1 when top is greater than the 1", () => {
        // Arrange
        const boundingBox = {};
        const rekognitionResponse = {
            FaceDetails: [
                {
                    AgeRange: {
                        High: 43,
                        Low: 26,
                    },
                    BoundingBox: {
                        Height: 0.6968063116073608,
                        Left: 0.26937249302864075,
                        Top: 1.11424895375967026,
                        Width: 5.42325547337532043,
                    },
                },
            ],
        };
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        // Act
        imageHandler["handleBounds"](rekognitionResponse, 0, boundingBox);
        // Assert
        expect(boundingBox).toEqual({
            Height: 0,
            Left: 0.26937249302864075,
            Top: 1,
            Width: 1 - 0.26937249302864075,
        });
    });
    it("Should set bounding box with a top set to 0 when top is less than the 0", () => {
        // Arrange
        const boundingBox = {};
        const rekognitionResponse = {
            FaceDetails: [
                {
                    AgeRange: {
                        High: 43,
                        Low: 26,
                    },
                    BoundingBox: {
                        Height: 0.6968063116073608,
                        Left: 0.26937249302864075,
                        Top: -0.11424895375967026,
                        Width: 5.42325547337532043,
                    },
                },
            ],
        };
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        // Act
        imageHandler["handleBounds"](rekognitionResponse, 0, boundingBox);
        // Assert
        expect(boundingBox).toEqual({
            Height: 0.6968063116073608,
            Left: 0.26937249302864075,
            Top: 0,
            Width: 1 - 0.26937249302864075,
        });
    });
    it("Should set bounding box with a left set to 1 when left is greater than the 1", () => {
        // Arrange
        const boundingBox = {};
        const rekognitionResponse = {
            FaceDetails: [
                {
                    AgeRange: {
                        High: 43,
                        Low: 26,
                    },
                    BoundingBox: {
                        Height: 0.6968063116073608,
                        Left: 8.26937249302864075,
                        Top: 0.11424895375967026,
                        Width: 0.42325547337532043,
                    },
                },
            ],
        };
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        // Act
        imageHandler["handleBounds"](rekognitionResponse, 0, boundingBox);
        // Assert
        expect(boundingBox).toEqual({
            Height: 0.6968063116073608,
            Left: 1,
            Top: 0.11424895375967026,
            Width: 0,
        });
    });
    it("Should set bounding box with a left set to 0 when left is less than the 0", () => {
        // Arrange
        const boundingBox = {};
        const rekognitionResponse = {
            FaceDetails: [
                {
                    AgeRange: {
                        High: 43,
                        Low: 26,
                    },
                    BoundingBox: {
                        Height: 0.6968063116073608,
                        Left: -0.26937249302864075,
                        Top: 0.11424895375967026,
                        Width: 0.42325547337532043,
                    },
                },
            ],
        };
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        // Act
        imageHandler["handleBounds"](rekognitionResponse, 0, boundingBox);
        // Assert
        expect(boundingBox).toEqual({
            Height: 0.6968063116073608,
            Left: 0,
            Top: 0.11424895375967026,
            Width: 0.42325547337532043,
        });
    });
});
//# sourceMappingURL=smart-crop.spec.js.map